#include <stdio.h>
#define MAX 1000000

int main(void){
	int i;
	for(i = 0; i < MAX; i++)
		printf("x\n");
	return 0;
	
}